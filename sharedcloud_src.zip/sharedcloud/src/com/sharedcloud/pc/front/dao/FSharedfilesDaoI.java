package com.sharedcloud.pc.front.dao;

import com.sharedcloud.pc.dao.basedao.BaseDaoI;
import com.sharedcloud.pc.model.Sharedfiles;

public interface FSharedfilesDaoI  extends BaseDaoI<Sharedfiles> {

}
