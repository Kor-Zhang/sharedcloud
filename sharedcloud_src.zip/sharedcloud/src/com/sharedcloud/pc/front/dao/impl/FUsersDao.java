package com.sharedcloud.pc.front.dao.impl;

import com.sharedcloud.pc.dao.basedao.impl.BaseDao;
import com.sharedcloud.pc.front.dao.FUsersDaoI;
import com.sharedcloud.pc.model.Users;

public class FUsersDao extends BaseDao<Users> implements FUsersDaoI {
	
}
