package com.sharedcloud.pc.front.dao.impl;

import com.sharedcloud.pc.dao.basedao.impl.BaseDao;
import com.sharedcloud.pc.front.dao.FFilesDaoI;
import com.sharedcloud.pc.model.Files;

public class FFilesDao  extends BaseDao<Files> implements FFilesDaoI {

}
