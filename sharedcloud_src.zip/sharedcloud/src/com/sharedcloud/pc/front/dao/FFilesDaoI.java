package com.sharedcloud.pc.front.dao;

import com.sharedcloud.pc.dao.basedao.BaseDaoI;
import com.sharedcloud.pc.model.Files;

public interface FFilesDaoI  extends BaseDaoI<Files> {

}
