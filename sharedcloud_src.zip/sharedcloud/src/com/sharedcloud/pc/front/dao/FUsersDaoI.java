package com.sharedcloud.pc.front.dao;

import com.sharedcloud.pc.dao.basedao.BaseDaoI;
import com.sharedcloud.pc.model.Users;

public interface FUsersDaoI extends BaseDaoI<Users> {

}
