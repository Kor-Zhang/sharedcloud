package com.sharedcloud.pc.front.dao.impl;

import com.sharedcloud.pc.dao.basedao.impl.BaseDao;
import com.sharedcloud.pc.front.dao.FUploadHistoryDaoI;
import com.sharedcloud.pc.model.UploadHistory;

public class FUploadHistoryDao  extends BaseDao<UploadHistory> implements FUploadHistoryDaoI {

}
