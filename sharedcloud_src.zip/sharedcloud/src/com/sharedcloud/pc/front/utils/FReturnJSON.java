package com.sharedcloud.pc.front.utils;

import java.io.Serializable;

import com.sharedcloud.pc.utils.GReturnJSON;

public class FReturnJSON extends GReturnJSON{
	
	
}
