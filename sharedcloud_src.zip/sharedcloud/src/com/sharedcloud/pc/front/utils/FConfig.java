package com.sharedcloud.pc.front.utils;

import com.sharedcloud.pc.utils.GConfig;
/**
 * 前台配置信息
 * @author XiaoYu
 *
 */
public class FConfig extends GConfig {

/*	*//**
	 * 申明变量
	 *//*
	public final static String KEY_OF_HEADIMGPATH = "headImgPath";
*/	
	
}
