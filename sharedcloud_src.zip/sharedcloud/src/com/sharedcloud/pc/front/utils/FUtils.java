package com.sharedcloud.pc.front.utils;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;

import com.sharedcloud.pc.utils.GUtils;
/** 
 * 项目前台通用工具 1.0
 * @author Kor_Zhang
 *
 */
public class FUtils extends GUtils{
	
	
	
}
