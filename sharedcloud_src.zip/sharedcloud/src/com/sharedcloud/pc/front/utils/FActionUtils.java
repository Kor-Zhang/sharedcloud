package com.sharedcloud.pc.front.utils;

import com.sharedcloud.pc.utils.GActionUtils;

/**
 * 继承了GActionUtils对原生http操作
 * @author Kor_Zhang
 *
 */
public class FActionUtils extends GActionUtils{

}
