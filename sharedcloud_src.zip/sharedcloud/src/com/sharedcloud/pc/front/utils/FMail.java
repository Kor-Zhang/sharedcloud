package com.sharedcloud.pc.front.utils;

import com.sharedcloud.pc.utils.GMail;
/**
 * 前台邮件发送
 * @author XiaoYu
 *
 */
public class FMail extends GMail{
}
