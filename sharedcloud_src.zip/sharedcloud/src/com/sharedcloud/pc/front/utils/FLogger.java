package com.sharedcloud.pc.front.utils;

import com.sharedcloud.pc.utils.GLogger;

/**
 * 前台log4j
 * @author XiaoYu
 *
 */
public class FLogger extends GLogger{
}
