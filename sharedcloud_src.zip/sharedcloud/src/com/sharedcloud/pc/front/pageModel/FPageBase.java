package com.sharedcloud.pc.front.pageModel;

import com.sharedcloud.pc.pageModel.PageBase;
/**
 * 前台类，设置基本参数，用于继承
 * @author Kor_Zhang
 *
 */
public class FPageBase extends PageBase{
	
	
}