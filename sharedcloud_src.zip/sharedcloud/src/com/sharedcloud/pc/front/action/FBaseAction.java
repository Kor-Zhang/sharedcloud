package com.sharedcloud.pc.front.action;

import com.sharedcloud.pc.action.BaseAction;


/**
 * 前台的基础action类
 * @author Kor_Zhang
 *
 */
public class FBaseAction extends BaseAction{
	
	
}
