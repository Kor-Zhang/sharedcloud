package com.sharedcloud.pc.front.stati;

import com.sharedcloud.pc.stati.GStatic;

/**
 * 定义项目前台常量
 * @author Kor_Zhang
 *
 */
public class FStatic extends GStatic{
	
}
