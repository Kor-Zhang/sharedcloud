package com.sharedcloud.pc.action;

import java.sql.Timestamp;
import java.util.Date;

import com.sharedcloud.pc.utils.GActionUtils;
import com.sharedcloud.pc.utils.GReturnJSON;

/**
 * 项目基础action类
 * @author Kor_Zhang
 *
 */

public class BaseAction extends GActionUtils{
	
	
}
