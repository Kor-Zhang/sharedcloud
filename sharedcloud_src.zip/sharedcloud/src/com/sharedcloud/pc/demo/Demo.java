package com.sharedcloud.pc.demo;

import com.sharedcloud.pc.utils.GLogger;

public class Demo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		GLogger.info("46546");
	}

}
