var failure_div;
$(function($){
	/*failure_div = $("#failure_div");
	//显示信息，优先显示url的msg参数
	c(failure_div);
	a(getParam("msg"));
	if(getParam("msg")!=""||getParam("msg")!=undefined){
		failure_div.html(getParam("msg"));
	}*/
});
